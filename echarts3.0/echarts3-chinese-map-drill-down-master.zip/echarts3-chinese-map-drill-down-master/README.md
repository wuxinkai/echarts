# echarts3-chinese-map-drill-down
Echarts3中国地图下钻至县级

demo：https://touxing.github.io/echarts3-chinese-map-drill-down/index.html

![map drill down](./static/img/map.gif)
