module.exports={
    baseUrl: '/vue-echarts-map-demo',
}